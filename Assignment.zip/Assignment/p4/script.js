async function getWeather() {
    const apiKey = ' ae425d86bd804ca6bc080725242007';  // Replace 'YOUR_API_KEY' with your actual WeatherAPI.com API key
    const city = document.getElementById('city').value.trim();
    const weatherDiv = document.getElementById('weather');

    if (!city) {
        weatherDiv.innerHTML = 'Please enter a city name.';
        return;
    }

    const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('City not found');
        }

        const data = await response.json();
        displayWeather(data);
    } catch (error) {
        weatherDiv.innerHTML = error.message;
    }
}

function displayWeather(data) {
    const weatherDiv = document.getElementById('weather');
    const { location, current } = data;

    weatherDiv.innerHTML = `
        <h2>Weather in ${location.name}</h2>
        <p>Temperature: ${current.temp_c} °C</p>
        <p>Humidity: ${current.humidity} %</p>
        <p>Condition: ${current.condition.text}</p>
    `;
}
