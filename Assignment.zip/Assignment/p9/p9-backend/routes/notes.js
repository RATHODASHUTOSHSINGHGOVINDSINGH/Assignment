// routes/notes.js
const express = require('express');
const router = express.Router();
const Note = require('../models/Note');

router.post('/create-note', (req, res) => {
  const note = new Note({
    title: req.body.title,
    content: req.body.content,
    userId: req.body.userId
  });

  note.save((err, note) => {
    if (err) {
      console.error(err);
      res.status(500).send({ message: 'Error creating note' });
    } else {
      res.send({ message: 'Note created successfully' });
    }
  });
});