 // src/App.js
import React, { useState } from 'react';

const App = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [notes, setNotes] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const note = { title, content };
    const response = await fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(note)
    });
    const data = await response.json();
    setNotes([...notes, data]);
    setTitle('');
    setContent('');
  };

  return (
    <div>
      <h1>Notes App</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Title:
          <input type="text" value={title} onChange={(event) => setTitle(event.target.value)} />
        </label>
        <br />
        <label>
          Content:
          <textarea value={content} onChange={(event) => setContent(event.target.value)} />
        </label>
        <br />
        <button type="submit">Create Note</button>
      </form>
      <ul>
        {notes.map((note) => (
          <li key={note._id}>{note.title} - {note.content}</li>
        ))}
      </ul>
    </div>
  );
};

export default App;