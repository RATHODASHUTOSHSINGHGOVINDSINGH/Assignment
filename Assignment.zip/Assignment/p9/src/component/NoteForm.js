// src/components/NoteForm.js
import React, { useState } from 'react';

const NoteForm = ({ onSubmit }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit({ title, content });
    setTitle('');
    setContent('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Title" />
      <textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="Content" />
      <button type="submit">Add Note</button>
    </form>
  );
};

export default NoteForm;