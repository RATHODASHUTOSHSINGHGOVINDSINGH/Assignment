import React, { useState } from 'react';
import axios from 'axios';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState(null);
  const [error, setError] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    axios.post('http://localhost:3000/login', { username, password })
      .then((response) => {
        const token = response.data.token;
        setToken(token);
        localStorage.setItem('token', token);
        setError(null);  // Clear any previous errors on successful login
      })
      .catch((error) => {
        const errorMessage = error.response && error.response.data && error.response.data.error
          ? error.response.data.error
          : 'An unknown error occurred';
        setError(errorMessage);
      });
  };

  return (
    <div>
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <label>Username:</label>
        <input type="text" value={username} onChange={(event) => setUsername(event.target.value)} /><br />
        <label>Password:</label>
        <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} /><br />
        <input type="submit" value="Login" />
      </form>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {token && <p>Token: {token}</p>}
    </div>
  );
}

export default Login;
