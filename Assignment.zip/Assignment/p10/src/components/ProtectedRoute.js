import React from 'react';
import axios from 'axios';
import { useState,useEffect } from 'react';

const Protected = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.get('http://localhost:3001/protected', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
       .then((response) => {
          setUser(response.data.user);
        })
       .catch((error) => {
          console.error(error);
        });
    }
  }, []);

  if (!user) return <p>You are not authorized to access this page.</p>;

  return (
    <div>
      <h1>Protected Page</h1>
      <p>Welcome, {user.username}!</p>
    </div>
  );
};

export default Protected;