// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  }
});

userSchema.methods.generateAccessJWT = function() {
  return jwt.sign({ userId: this._id, username: this.email }, 'your_secret_key_here', { expiresIn: '1h' });
};

const User = mongoose.model('User', userSchema);

module.exports = User;