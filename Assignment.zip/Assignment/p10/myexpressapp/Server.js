const express = require('express');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const users = [
  { id: 1, username: 'j', password: bcrypt.hashSync('password123', 10) },
  { id: 2, username: 'jane', password: bcrypt.hashSync('password456', 10) },
];


const authenticate = async (username, password) => {
  const user = users.find((user) => user.username === username);
  if (user && await bcrypt.compare(password, user.password)) {
    return user;
  }
  return null;
};

const generateToken = (user) => {
  const payload = { userId: user.id, username: user.username };
  return jwt.sign(payload, process.env.JWT_SECRET || 'secretkey', { expiresIn: '1h' });
};

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  console.log(`Login attempt: ${username}`);  // Debugging login attempts
  const user = await authenticate(username, password);
  if (!user) {
    console.log('Authentication failed');  // Debugging failed authentication
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  const token = generateToken(user);
  console.log(`Generated token: ${token}`);  // Debugging token generation
  res.json({ token });
});

app.listen(process.env.PORT || 3000, () => {
  console.log(`Server listening on port ${process.env.PORT || 3000}`);
});
