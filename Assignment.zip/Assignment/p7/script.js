$(document).ready(function() {
    var slideIndex = 0;
    
    showSlides(slideIndex);
    
    $('.next').click(function() {
        slideIndex++;
        showSlides(slideIndex);
    });
    
    $('.prev').click(function() {
        slideIndex--;
        showSlides(slideIndex);
    });
    
    $('.dot').click(function() {
        slideIndex = $(this).index();
        showSlides(slideIndex);
    });
    
    function showSlides(index) {
        var slides = $('.slide');
        var dots = $('.dot');
        
        if (index >= slides.length) {
            slideIndex = 0;
        }
        if (index < 0) {
            slideIndex = slides.length - 1;
        }
        
        slides.hide();
        slides.eq(slideIndex).show();
        
        dots.removeClass('active');
        dots.eq(slideIndex).addClass('active');
    }
});
